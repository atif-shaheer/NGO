<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/main.css?v=1726033922">
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css-loader-master/dist/css-loader.css?v=1726033922">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.css" integrity="sha512-8D+M+7Y6jVsEa7RD6Kv/Z7EImSpNpQllgaEIQAtqHcI0H6F4iZknRj0Nx1DCdB+TwBaS+702BGWYC0Ze2hpExQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.js" integrity="sha512-Y+cHVeYzi7pamIOGBwYHrynWWTKImI9G78i53+azDb1uPmU1Dz9/r2BLxGXWgOC7FhwAGsy3/9YpNYaoBy7Kzg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.js"></script>
<script>
function alert_success(title){
    $.toast({
    heading: 'Success',
    text: title,
    showHideTransition: 'slide',
    icon: 'success'
    })
}
function alert_danger(title){
    $.toast({
    heading: 'Error',
    text: title,
    showHideTransition: 'slide',
    icon: 'error'
    })
}
</script>
<style>
    .cke_notifications_area { display: none; }
</style>
  <link rel="stylesheet" href="css/admin.css?v=1726033922">
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark">
 <h4 class="text-white ml-auto mr-auto mt-auto mb-auto nav-heading">Admin Dashboard</h4>
</nav>
<style media="screen">
* {
margin: 0;
padding: 0;
}
.agent-data {
width: 90%;
}
.loader{
    z-index:999999999999;
}
td{
vertical-align: middle!important;
}
body {
background: linear-gradient(90deg, rgba(233, 233, 240, 1) 48%, rgba(227, 241, 241, 1) 100%);
}
.bg-opacity{
opacity: .5!important;
user-select: none!important;
pointer-events: none;
cursor: default;
}
.navbar {
background: rgb(255,17,25);
background: linear-gradient(180deg, rgba(255,17,25,1) 0%, rgba(255,143,39,1) 100%);
z-index: 4;
}
#menu_click_btn,#home_btn_class{
color: #DF2800;
font-size: 20px;
border: 1px solid white;
padding: 3px 8px 3px 8px;
border-radius: 5px;
background: white;
position: absolute;
top: 10px;
left: 10px;
z-index: 999999;
}
.modal-backdrop{
    z-index:999999;
}

#home_btn_class{
left:50px;
}
.navbar .fa-bars:hover,.fa-times:hover{
color: #DF2800;
border-radius: 5px;
}
.nav-heading{
text-align: center;
}
.menu{
background: rgb(255,17,25);
background: linear-gradient(180deg, rgba(255,17,25,1) 0%, rgba(255,143,39,1) 100%);
z-index: 3;
width: 180px;
position: absolute;
top: -150%;
overflow: hidden;
left: 0;
opacity: .9;
transition: 1s;
}
.menu a{
  font-size: 15px;
  font-weight: bold;
}
.menu-click{
top: 43px;
transition: .2s;
opacity: .9;
}
.navbar-nav a{
color: white!important;
text-transform: uppercase!important;
padding: 7px 20px!important;
}
.navbar-nav li:hover{
background: black;
}
.contact-footer {
height: 200px;
background: linear-gradient(90deg, rgba(93, 80, 102, 1) 0%, rgba(59, 84, 99, 1) 50%, rgba(72, 52, 52, 1) 100%);
}
tbody  {
background: linear-gradient(0deg, rgba(235,230,240,1) 0%, rgba(253,249,254,1) 100%);
}
.agent-data {
overflow-x: auto;
}
#action-btn  {
  gap:5px;
  justify-content: center;
text-align: center;
display: flex;
width: auto;
}
#search-bar{
position: relative;
width: 250px;
float: right ;
margin-right: 10px;
margin-top: 20px;
margin-bottom: 10px;
}
#search-bar .fa{
position: absolute;
top: 9px;
right:10px;
}
.nav-link{
  font-size: 12px!important;
}
@media screen and (max-width:970px) {
.nav-head {
font-size: 25px;
margin: auto;
}
nav button {
font-size: 14px !important;
padding: 5px !important;
}
}
@media screen and (max-width:780px) {
.menu-click{
top: 45px!important;
transition: .2s;
border-bottom-left-radius: 5px;
border-bottom-right-radius: 5px;
opacity: .9;
}
.menu{
width: 100%;
}
.nav2{
display: block;
text-align: center;
z-index: -1;
}
.nav-head {
font-size: 18px;
}
nav button {
float: right !important;
font-size: 12px !important;
padding: 1px !important;
}
#create-agent,#create-user {
position: absolute;
top: 60.5px;
right: 50px;
}
#Logout {
position: absolute;
top: 60.5px;
right: 5px;
}
#search-bar{
position: relative;
margin-top: 30px!important;
}
#admin-name{
font-size: 16px!important;
position: relative;
left: -10px;
top: 8px;
}
#admin-home{
position: absolute;
right: 10px;
top: 60.5px!important;
}
thead{
}
thead,tbody{
font-size: 14px;
}
#admin-t{
width: 630px!important;
}
#agent-t{
width: 800px!important;
}
#ai{
width: 100px;
}
#name{
width: 150px;
}
#mob{
width: 110px;
}
#city{
width: 100px;
}
#jd{
width: 150px;
}
#vd{
width: 120px;
}
#action{
width: 220px;
}
#t-report{
width:260px;
}
#b-report{
position: absolute;
right: 10px;
padding: 6px!important;
}
#Home{
position: absolute;
top: 59px;
right: 10px;
padding: 3px!important;
}
}
@media screen and (max-width:600px) {
.nav2{
text-align: left;
}
#search-bar{
position: relative;
width: 94%;
}
input[type="radio"]{
}
#admin-t thead,#agent-t thead{
display: none!important;
}
#admin-t,#agent-t, #admin-t tbody,#agent-t tbody, #admin-t tr,#agent-t tr, #admin-t td, #agent-t td{
display: block!important;
width:100%!important;
}
#admin-t tr,#agent-t tr{
margin-bottom: 20px!important;
}
#admin-t td, #agent-t td{
text-align: right!important;
padding-left: 20%!important;

text-align: right!important;
position: relative!important;
}
#admin-t td div, #agent-t td div{
display: flex;
grid-gap: 5px;
justify-content: right!important;
}
#admin-t td::before, #agent-t td::before{
content: attr(data-label);
position: absolute;
left: 0;
width: 50%;
padding-left: 15px;
font-weight: bold;
text-align: left;
}
#admin-t{
width: 100%!important;
border: none!important;
background:white!important;
}
#agent-t{
width: 100%!important;
border: none!important;
background:white!important;
}
#status{
padding: 0px 2px 0px 2px!important;
font-size: 14px;
margin-left: 1px!important;
}
#edit{
padding:0px 2px 0px 2px;
font-size: 14px;
}
tbody{
background: linear-gradient(90deg, rgba(233, 233, 240, 1) 48%, rgba(227, 241, 241, 1) 100%);
}
tbody tr  {
background: linear-gradient(0deg, rgba(235,230,240,1) 0%, rgba(253,249,254,1) 100%);
border: 1px solid grey;
}
td[data-label="Name"]{
font-weight: 500;
}
.container-fluid{
width: 95%!important;
}
}

</style>
 <i id="menu_click_btn" class="toggle fa fa-bars fa-times" aria-hidden="true"></i>
 <i id="home_btn_class" class="fa fa-home" aria-hidden="true"></i>
<div class="menu">
    <div class="navbar-collapse" id="navbarNav">
  <ul class="navbar-nav">

    <li class="nav-item active">
      <a class="nav-link" href="admin.php">Dashboard</a>
    </li>
    <li class="nav-item active">
      <a class="nav-link" href="unverified-user-list.php">Unverified Users</a>
    </li>

    <li class="nav-item active">
      <a class="nav-link" href="verified-users-list.php">Verified Users</a>
    </li>

    <li class="nav-item active">
      <a class="nav-link" href="coordinator-team-list.php">Coordinator  List</a>
    </li>   <li class="nav-item active">
      <a class="nav-link" href="council-list.php">Certificate List</a>
    </li>
    <li class="nav-item active">
      <a class="nav-link" href="coordinator-report.php">Coordinator Report</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="booking-list.php">Seat Booked</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="event-list.php">All Event</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="timeline-post-list.php">All Post</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="participant-list.php">Participant List</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="management-team-list.php">Management Team</a>
    </li>

     <li class="nav-item">
      <a class="nav-link" href="public-user-list.php">Public User List</a>
    </li>

     <li class="nav-item">
      <a class="nav-link" href="contact-us-list.php">Contact List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="receipt-application-list.php">Receipt Application List</a>
    </li>

    <li class="nav-item active">
      <a class="nav-link" href="complain-list.php">Complain / Solution</a>
    </li>
    <li class="nav-item active">
      <a class="nav-link" href="testimonial-list.php">Testimonial</a>
    </li>
    <li class="nav-item active">
      <a class="nav-link" href="donation_list.php">Print Donation Slip</a>
    </li>

    <li class="nav-item active">
      <a class="nav-link" href="message-us-list.php">My Message</a>
    </li>

     <li class="nav-item active">
      <a class="nav-link" href="slider_image.php">Slider Images</a>
    </li> 


    <li class="nav-item">
      <a class="nav-link" href="company-profile.php">Company Profile</a>
    </li>

     <li class="nav-item">
      <a class="nav-link" href="aboutus-post-list.php">About Us Post List</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="motive-list.php">Objective List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="our-project-list.php">Project List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="profile.php">Profile</a>
    </li>


    <li class="nav-item">
      <a class="nav-link" href="admin-logout.php">Logout</a>
    </li>
  </ul>
</div>
</div>

<script type="text/javascript">
   $(document).ready(function(){

     //Create Agent
     $('#create-agent').click(function(){
       window.location.href="agent-form.php?admin_id=";
     });

     $('.toggle').click(function(){
       $('.toggle').toggleClass('fa-bars');
       $('table').toggleClass('bg-opacity');
     });


     //Toggle
     $('.toggle').click(function(){
       $('.menu').toggleClass("menu-click");
     });

     //Logout Button
     $('#Logout').click(function(){
       window.location.href="admin-logout.php";
     });

     //Report Button
     $('#report').click(function(){
       window.location.href="report.php";
     });
     $('#home_btn_class').click(function(){
       window.location.href="admin.php";
     });

   });
   </script>
              <center>
    <div class="agent-data ml-auto mr-auto mt-5 container-fluid" id="table-data">

    </div>
  </center>

<script type="text/javascript">
   $(document).ready(function(){
     //Live Search
     $('#search').on("keyup",function(){
       var search_item = $(this).val();

       $.ajax({
         url: "ajax-users-search.php",
         type: "POST",
         data : {search:search_item},
         success: function(data){
           $("#table-row").html(data);
         }
       });
     });
    //Pagination ajax
     function loadTable(page){
       $.ajax({
         url: "admin-pagination.php",
         type: "POST",
         data: {page_no :page},
         success: function(data){
           $('#table-data').html(data);
         }
       });
     }
     loadTable();

     //Pagination code

     $(document).on("click",".page-link",function(e){
       e.preventDefault();
       var page_id = $(this).attr("id");
       loadTable(page_id);
     });


   });

</script>
</body>
</html>
