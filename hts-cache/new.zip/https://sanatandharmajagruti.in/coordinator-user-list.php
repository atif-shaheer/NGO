<!DOCTYPE html>
<html lang="en">
<head>
  <title>Coordinator</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/main.css?v=1726033959">
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css-loader-master/dist/css-loader.css?v=1726033959">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.css" integrity="sha512-8D+M+7Y6jVsEa7RD6Kv/Z7EImSpNpQllgaEIQAtqHcI0H6F4iZknRj0Nx1DCdB+TwBaS+702BGWYC0Ze2hpExQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.js" integrity="sha512-Y+cHVeYzi7pamIOGBwYHrynWWTKImI9G78i53+azDb1uPmU1Dz9/r2BLxGXWgOC7FhwAGsy3/9YpNYaoBy7Kzg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.js"></script>
<script>
function alert_success(title){
    $.toast({
    heading: 'Success',
    text: title,
    showHideTransition: 'slide',
    icon: 'success'
    })
}
function alert_danger(title){
    $.toast({
    heading: 'Error',
    text: title,
    showHideTransition: 'slide',
    icon: 'error'
    })
}
</script>
<style>
    .cke_notifications_area { display: none; }
</style>
  <link rel="stylesheet" href="css/admin.css?v=1726033959">
      <link rel="stylesheet" href="css/user-form.css?v=1726033959">
  <style>
          .modal-dialog{
               max-width:100%!important;
               margin:0px auto;
           }
    .donation{
    margin: auto;
    margin-top: 20px;
    width: auto;
    height: auto;
    padding: 10px;
    padding-left: 30px;
    /* text-align: center; */
    box-shadow: 0px 0px 5px 2px lightgrey;
    border-radius: 10px;
    background: linear-gradient(184deg, rgba(241,97,6,1) 0%, rgba(237,92,0,1) 100%);

    }
    .donation p{
    /* margin-top:20px; */
    font-size: 20px;
    color: #fff;
    }
	.qrcode{
    margin: auto;
    margin-top: 20px;
    width: 250px;
    height: auto;
    padding: 20px;
    text-align: center;
    box-shadow: 0px 0px 5px 2px lightgrey;
    border-radius: 10px;
    background-color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    }

   @media only screen and (max-width: 600px) {
    .donation {
      width:100%;
      margin: auto;
    }
    .donation p {
    font-size: 18px;
    }

    }
    @media only screen and (max-width: 370px) {
      .donation {
      width: 100%;
      }
      .donation p {
      font-size: 18px;
      }

    }
  </style>
</head>
<body>
    <div class="loader loader-double"></div>
  <nav class="navbar navbar-expand-md navbar-dark">
   
<style media="screen">
  .navbar{
    height: 60px!important;
  }
  #brand{
      color:white;
      font-family: 'Bree Serif', serif;


  }
@media screen and (max-width:770px) {
  .navbar{
    height: 54px!important;
  }
  .nav2{
    height: 36px!important;
  }
}
.navbar{
background: #0575E6;
background: -webkit-linear-gradient(to right, #021B79, #0575E6); 
background: linear-gradient(to right, #021B79, #0575E6);
}
</style>

   <h4 class="text-white ml-auto mr-auto mt-auto mb-auto nav-heading">User List</h4>
   <a href="coordinator-logout.php" class="btn btn-light">Logout</a>
  </nav>

  <center>
     <button type="button" id="add_user_btn" class="btn btn-primary d-block btn-sm mx-auto mt-3" name="button">Add User</button>
  </center>

  <!-- <center>
   <div id="search-bar">
    <i class="fa fa-search" aria-hidden="true"></i>
    <input type="text" class="form-control" id="search" placeholder=" User Search" autocomplete="off">
   </div>
  </center> -->
  <center>
    <div class="agent-data ml-auto mr-auto mt-3 container-fluid" id="table-data">

    </div>
  </center>
<div class="modal fade" id="addFormModel" tabindex="-1" aria-labelledby="addFormModelLabel" aria-hidden="true" style="z-index:99999999;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="addFormModelLabel">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body addFormData">
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script src="js/cities.js"></script>
<script type="text/javascript">
   $(document).ready(function(){

  
     // $('#search').on("keyup",function(){
     //   var search_item = $(this).val();

     //   $.ajax({
     //     url: "ajax-users-search.php",
     //     type: "POST",
     //     data : {search:search_item},
     //     success: function(data){
     //       $("#table-row").html(data);
     //     }
     //   });
     // });
    //Pagination ajax

     function loadTable(page){
         $('.loader').addClass('is-active');
       $.ajax({
         url: "ajax/coordinator-user-pagination.php",
         type: "POST",
         data: {page_no :page},
         success: function(data){
             $('.loader').removeClass('is-active');
           $('#table-data').html(data);
         }
       });
     }
     loadTable();

     $(document).on("click",".page-link",function(e){
       e.preventDefault();
       var page_id = $(this).attr("id");
       loadTable(page_id);
     });
          // delete user
     $(document).on('click','#delete_c_u',function(e){
         e.preventDefault();
      var id = $(this).attr('data-id'); 
      var page_id = $(this).attr('data-page');
      
      if (confirm("Are you sure you want to delete ?") == true) {
          $('.loader').addClass('is-active');
      $.ajax({
        url:"ajax/delete-users.php",
        type:"post",
        data:{Userid:id},
        success:function(data){
            $('.loader').removeClass('is-active');
            if(data == 1){
            alert('User has been deleted successfully')
          loadTable(page_id);
            }else{
                alert('Something went wrong');
            }
        }
      })
      }
     })
     
        $(document).on("click","#add_user_btn",function(e){
       e.preventDefault();
       var user_id = $(this).attr('data-id');
       $('.loader').addClass('is-active');
       $.ajax({
           url:"add/coordinator_add_user_form.php",
           type:"post",
           success:function(data){
                $('.loader').removeClass('is-active');
               $('.addFormData').html(data);
             $('#addFormModel').modal('show');
           }
       })
      
     });  
     
     $(document).on("submit","#insert_form",function(e){
         e.preventDefault();
        $('.loader').addClass('is-active');
          $.ajax({
              url:"update/insert_coordinator_user_form.php",
              type:"post",
              data: new FormData(this),
              processData: false,
              contentType: false,
              success:function(data){
                  $('.loader').removeClass('is-active');
                    loadTable();
                    $('#addFormModel').modal('hide');
                  
              }
          })
      
     });

   });

</script>
</body>
</html>
