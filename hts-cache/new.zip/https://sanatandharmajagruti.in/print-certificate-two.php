<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="utf-8">
    <title>Appointment Letter</title>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://kendo.cdn.telerik.com/2017.2.621/js/kendo.all.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style type="text/css">
    .certificate_img{
    width: 700px;
    display: block;
    margin-left: auto;
    margin-right: auto;
    position: relative;
    }
    #certificate_img{
    height: 100%;
    width: 100%;
    }
    #profile{
    position: absolute;
    top: 225px;
    right: 140px;
    border: 2px solid #FF6600;
    border-radius: 10px;
    }
    .detail{
    position: absolute;
    transform:translate(-50%);
    top: 250px;
    left:50%;
    width:90%;
    }
    .detail p{
    text-align:justify;
    font-size: 12px;
    font-weight: bold;
    color:black;
    }
    .detail p span{
    color:#EC3237;
    }
    .note{
        position: absolute;
    bottom: 40px;
    left:30px;
    width:70%;
    }
    .note p{
        text-align:justify;
    font-size: 8px;
    font-weight: bold;
    color:black;
    }
    #sign{
    position: absolute;
    right:50px;
    bottom: 90px;
    }
    .date {
    position: absolute;
     top: 220px;
    right: 17px;
    line-height: 1;
    font-weight: bold;
    } 
    .id p{
    position: absolute;
    top: 220px;
    left: 30px;
    font-size: 12px;
    font-weight: bold;
    }
    </style>
  </head>
  <body>
      </body>
  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
  <script>
  const elementToSave = document.querySelector("#row");
  // Download with right click
  function screenshot(){
  html2canvas(elementToSave).then(canvas => {
  const a = document.createElement("a");
  a.href = canvas.toDataURL("Appointment_letter/png");
  a.download = "_Appointment_letter.png";
  a.click();
  });
  }
  </script>
</html>